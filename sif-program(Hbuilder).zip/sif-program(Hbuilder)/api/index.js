import { get, post } from '../common/request.js'
// export function getUserInfo(params) {
// 	try {
// 	    const result =  post('/api/monitorSnapshot/queryList',params)
//         return result
// 	  } catch (error) {
// 	    // 错误已在拦截器处理
// 	  }
// }
// https://api.weixin.qq.com/cgi-bin/token 



export function getLoginApi(params) {
	try {
	    const result =  get('https://api.weixin.qq.com/sns/jscode2session',
            {
                appid:"wxa5369c34ce6866f3",
                secret:'aad413dd258e3d1f03d733a5987ab4af',
                grant_type:'authorization_code',
                ...params
            }
            ,{ignoreBASEURL:true})
        return result
	  } catch (error) {
        console.log(error)
	  }
}
export function getAccessTokenApi(params) {
    // 
	try {
	    const result =  get('https://api.weixin.qq.com/cgi-bin/token',{grant_type:"client_credential",appid:"wxa5369c34ce6866f3",secret:'aad413dd258e3d1f03d733a5987ab4af'},{ignoreBASEURL:true})
        return result
	  } catch (error) {
        console.log(error)
	  }
}
export function subscribeSendApi(params) {
	try {
        let {access_token,...rest} = params
	    const result =  post(`https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token=${access_token}`,rest,{ignoreBASEURL:true})
        return result
	  } catch (error) {
        console.log(error)
	  }
}