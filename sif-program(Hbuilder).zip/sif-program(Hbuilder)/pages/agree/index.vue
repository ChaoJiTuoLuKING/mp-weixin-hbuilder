<template>
    <view class="agree-page-box">
        <rich-text :nodes="privacyPolicyContent"></rich-text>

    </view>
</template>

<script  setup>
import { ref } from "vue";
// 隐私政策内容（可以是富文本）
const privacyPolicyContent = ref(`
  <h1 style="color:red">测试文本</h1>
  <h3>隐私政策</h3>
  <p><strong>1. 信息收集</strong></p>
  <p>我们收集的信息包括但不限于：</p>
  <ul>
    <li>您提供的个人信息（如昵称、头像等）</li>
    <li>设备信息（如设备型号、操作系统版本等）</li>
    <li>使用信息（如功能使用情况、访问时间等）</li>
  </ul>
  <p><strong>2. 信息使用</strong></p>
  <p>收集的信息将用于：</p>
  <ul>
    <li>提供和改善我们的服务</li>
    <li>个性化您的用户体验</li>
    <li>与您沟通重要信息</li>
  </ul>
  <p><strong>3. 信息安全</strong></p>
  <p>我们采取合理措施保护您的信息安全...</p>
`);
</script>
<style lang="scss" scoped>
.agree-page-box{
    padding: 20rpx;
    // text-align: center;
}

</style>