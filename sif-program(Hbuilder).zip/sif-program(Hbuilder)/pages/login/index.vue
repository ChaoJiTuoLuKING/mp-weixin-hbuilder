<template>
  <loginPopup ref="popup"></loginPopup>

  <view class="center">
    <view class="logo" :hover-class="!login ? 'logo-hover' : ''">
      <button
        class="avatar-wrapper"
        open-type="chooseAvatar"
        @chooseavatar="onChooseAvatar"
      >
        <image class="logo-img" :src="avatarUrl"></image>
      </button>
      <view class="logo-title" @click="handleLogin">
        <text class="uer-name">{{ userStore.userInfo.nickName || "登录 / 注册" }}</text>
      </view>
    </view>
    <view class="center-list">
      <view class="center-list-item border-bottom">
        <uni-icons type="contact" size="30"></uni-icons>
        <text class="list-text">账号管理</text>
      </view>
    </view>
    <view class="center-list">
      <view class="center-list-item border-bottom">
        <uni-icons type="contact" size="30"></uni-icons>
        <text class="list-text">帮助与反馈</text>
      </view>
    </view>
    <view class="center-list">
      <view class="center-list-item border-bottom">
        <uni-icons type="contact" size="30"></uni-icons>
        <text class="list-text">服务条款及隐私</text>
      </view>
    </view>
    <view class="center-list">
      <view class="center-list-item border-bottom">
        <uni-icons type="contact" size="30"></uni-icons>
        <text class="list-text">关于我们</text>
      </view>
    </view>
  </view>
  <!-- <button
    class="login-btn"
    open-type="getRealtimePhoneNumber"
    @getphonenumber="getPhoneNumber"
  >
    授权手机号登录
  </button> -->
</template>

<script setup>
import { ref } from "vue";
import { useUserStore } from "@/stores/user.js";
import loginPopup from "@/components/loginPopup.vue";

const login = ref(false);
const avatarUrl = ref("/static/user.png");
const popup = ref(null);
const userStore = useUserStore();

const onChooseAvatar = async (e) => {
    try {
    console.log("chooseAvatar", e);
    // 使用本地文件系统保存头像
    const tempFilePath = e.detail.avatarUrl;
    avatarUrl.value = tempFilePath;
  } catch (error) {
    console.error("头像选择失败:", error);
    uni.showToast({
      title: '头像选择失败',
      icon: 'none'
    });
  }
    // console.log("chooseAvatar", e);
//   avatarUrl.value = e.detail.avatarUrl;
};
const handleLogin = async () => {
console.log("handleLogin");
  uni.hideTabBar({
    animation: true,
  });
  console.log("handleLogin", popup.value);
  popup.value.open("bottom");
};
</script>

<style lang="scss">
.popup-content {
  width: 100%;
  height: 300rpx;
}
.avatar-wrapper {
  background: none;
  border: none;
  padding: 0;
  margin: 0;
  outline: none;
  box-shadow: none;
  line-height: 100%;
}

.avatar-wrapper::after {
  border: none;
}
.center {
  width: 100%;
  flex: 1;
  flex-direction: column;
  background-color: $white-text-color;
}

.logo {
  height: 200rpx;
  padding: 20rpx 40rpx;
  background-color: $primary-color;
  display: flex;
  flex-direction: row;
  align-items: center;
}

.logo-hover {
  opacity: 0.8;
}

.logo-img {
  width: 150rpx;
  height: 150rpx;
  border-radius: 150rpx;
}

.logo-title {
  //   height: 150rpx;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  flex-direction: row;
  margin-left: 20rpx;
}

.uer-name {
  height: 60rpx;
  line-height: 60rpx;
  font-size: 38rpx;
  color: $text-color;
}

.go-login-navigat-arrow {
  font-size: 38rpx;
  color: #ffffff;
}

.login-title {
  height: 150rpx;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-left: 20rpx;
}

.center-list {
  flex-direction: column;
  background-color: #ffffff;
  margin-top: 20rpx;
  padding: 0 40rpx;
  //   width: 750rpx;
}

.center-list-item {
  height: 90rpx;
  line-height: 90rpx;
  //   width: 750rpx;
  display: flex;
  flex-direction: row;
  //   padding: 0rpx 20rpx;
}

.border-bottom {
  border-bottom-width: 1rpx;
  border-color: $tip-border-color;
  border-bottom-style: solid;
}

.list-icon {
  width: 40rpx;
  height: 90rpx;
  line-height: 90rpx;
  font-size: 34rpx;
  color: #2f85fc;
  text-align: center;
  font-family: texticons;
  margin-right: 20rpx;
}

.list-text {
  height: 90rpx;
  line-height: 90rpx;
  font-size: 34rpx;
  color: #555;
  flex: 1;
  margin-left: 10px;
}

.navigat-arrow {
  height: 90rpx;
  width: 40rpx;
  line-height: 90rpx;
  font-size: 34rpx;
  color: #555;
  text-align: right;
  font-family: texticons;
}
</style>
