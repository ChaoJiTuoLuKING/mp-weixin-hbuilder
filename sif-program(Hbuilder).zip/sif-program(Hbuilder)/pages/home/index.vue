<template>
  <view class="login-container">
    <view class="login-header">
      <image
        src="https://gonglan-monitor.oss-cn-shenzhen.aliyuncs.com/Picture/pages/home/00-logo/sif%20logo.png"
        class="app-logo"
      ></image>
      <text class="app-name">Sif</text>
    </view>
    <view class="content">
      <view class="text-area">
        <button
          class="sub-subscription-btn"
          @click="subscriptionBtn"
          :style="{ backgroundColor: loading ? '#b0e4c8' : '#07C160' }"
        >
          订阅信息
        </button>
        <button
          class="sub-subscription-btn"
          @click="handleSend"
          :style="{ backgroundColor: loading ? '#b0e4c8' : '#07C160' }"
        >
          发送订阅信息
        </button>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { getAccessTokenApi, subscribeSendApi } from "../../api/index";
import { useUserStore } from "../../stores/user.js";

import env from "@/common/env.js";

const userStore = useUserStore();
const tmplId = "SbPn16zKGZ-MRgrtgZrL6gRUBOvxpPBFT6p6FwcD0yk";
const handleSend = async () => {
  let res = await subscribeSendApi({
    access_token: userStore.access_token,
    template_id: tmplId,
    touser: userStore.openid,
    miniprogram_state: env.miniprogram_state,
    lang: "zh_CN",
    page: "pages/login/index",
    data: {
      thing1: { value: "审核通过thing1" },
      number2: { value: 2 },
      number3: { value: 3 },
      thing4: { value: "温馨提示说" },
      thing5: { value: "纯净水596ml" },
    },
  });
  if(res.errcode === 0 && res.errmsg === "ok"){
    uni.showToast({
      title: "发送订阅信息成功",
      icon: "none",
    });
  }
};  
const subscriptionBtn = async () => {
  wx.requestSubscribeMessage({
    tmplIds: [tmplId],
    success(res) {
      if (res.errMsg === "requestSubscribeMessage:ok" && res[tmplId] === "accept") {
        console.log("订阅成功");
        uni.showToast({
          title: "订阅信息成功",
          icon: "none",
        });
      } else {
      }
      console.log(res, "res");
    },
  });
  return;
};
const getAccessToken = async () => {
  try {
    const res = await getAccessTokenApi();
    userStore.setAccessToken(res.access_token);
   
  } catch (error) {
    console.error("获取token失败", error);
  }
};
onMounted(() => {
  getAccessToken();
});
</script>

<style lang="scss">
.login-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
  padding: 40rpx;
  /* background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); */
  // color:var(--primary-color) !important;

  //   background-color: $primary-color;
}

.login-header {
  /* flex: 4; */
  display: flex;
  height: 500rpx;

  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.app-logo {
  width: 130rpx;
  height: 20rpx;
  /* border-radius: 24rpx; */
  margin-bottom: 30rpx;
  /* background-color: rgba(255, 255, 255, 0.2); */
  padding: 20rpx;
  object-fit: cover;
}

.app-name {
  font-size: 48rpx;
  font-weight: bold;
  margin-bottom: 16rpx;
}

.sub-subscription-btn {
  width: 80%;
  height: 90rpx;
  border-radius: 45rpx;
  color: white;
  font-size: 32rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 60rpx;
  box-shadow: 0 10rpx 20rpx rgba(7, 193, 96, 0.3);
  border: none;
  outline: none;
}

.sub-subscription-btn:active {
  opacity: 0.9;
  transform: translateY(4rpx);
}

.sub-subscription-btn[disabled] {
  opacity: 0.7;
}

.loading-icon {
  width: 40rpx;
  height: 40rpx;
  margin-right: 20rpx;
  border: 3rpx solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top: 3rpx solid white;
  animation: rotate 1s linear infinite;
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.login-content {
}
</style>
