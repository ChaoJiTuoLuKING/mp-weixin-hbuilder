import { defineStore } from 'pinia'
import permission from '../common/permission.js'

export const useUserStore = defineStore('user', {
  // 状态
  state: () => ({
    openid:'',
    session_key:"",
    access_token:"",
    userInfo: {},
    token: uni.getStorageSync('token') || '',
    isLoggedIn: !!uni.getStorageSync('token')
  }),
  
  // 计算属性
  getters: {
    // 是否有用户信息
    hasUserInfo: (state) => state.userInfo
  },
  
  // 方法
  actions: {
   
    setOpenid(value) {
      this.openid = value
    },
    setSessionKey(value) {
      this.session_key = value
    },
    setAccessToken(value) {
      this.access_token = value
    },
     // 设置用户信息
     setUserInfo(userInfo) {
        this.userInfo = userInfo
      },
    
    
    // 清除用户信息
    clearUserInfo() {
      this.userInfo = null
      this.token = ''
      this.isLoggedIn = false
      uni.removeStorageSync('token')
    },
    
    
    // 登出
    logout() {
      this.clearUserInfo()
      // 跳转到登录页
      permission.redirectToLogin()
    },
    
    // 更新用户信息
    updateUserInfo(userInfo) {
      this.userInfo = { ...this.userInfo, ...userInfo }
    }
  }
})