# sif小程序非cli版本  不依赖node环境

> uni-app+vue3
