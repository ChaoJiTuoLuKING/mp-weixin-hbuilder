<script>
import permission from "./common/permission.js";

export default {
  onLaunch: function () {
    console.log("App Launch savedTheme");
    // 监听页面跳转
    // uni.addInterceptor("navigateTo", {
    //   invoke: (args) => {
    //     console.log(permission.isNeedLogin(args.url) && !permission.checkLogin(),"navigateTo", args);
    //     // 检查目标页面是否需要登录
    //     if (permission.isNeedLogin(args.url) && !permission.checkLogin()) {
    //       // 未登录且需要登录权限，跳转到登录页
    //       permission.redirectToLogin();
    //       return false; // 阻止原跳转
    //     }
    //     return args; // 继续原跳转
    //   },
    // });
    // uni.addInterceptor("switchTab", {
    //   invoke: (args) => {
    //     console.log("switchTab", args);

    //     // 检查目标页面是否需要登录
    //     if (permission.isNeedLogin(args.url) && !permission.checkLogin()) {
    //       // 未登录且需要登录权限，跳转到登录页
    //       permission.redirectToLogin();
    //       return false; // 阻止原跳转
    //     }
    //     return args; // 继续原跳转
    //   },
    // });
  },
  onShow: function () {
    console.log("App Show");
  },
  onHide: function () {
    console.log("App Hide");
  },
};
</script>

<style lang="scss">
@import "@/styles/global.scss";
</style>
