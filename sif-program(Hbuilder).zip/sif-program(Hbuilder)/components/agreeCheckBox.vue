<template>
  <!-- multiple -->
  <view class="agree-box">
    <CustomCheckbox
      v-model="agreedValue"
      :localdata="[
        {
          text: '我已经阅读并同意',
          value: 1,
        },
      ]"
      @change="onValueChanged"
    />
    <view class="agree-text" @click="agreedClick">《用户协议》</view>
  </view>
</template>

<script setup>
import CustomCheckbox from "./customCheckbox.vue";
import { ref ,watch} from "vue";

const agreedValue = ref(0);
const emit = defineEmits(["agreedValue"]);

const onValueChanged = (e) => {
    console.log(e,'pppp');
}
const agreedClick = () => {
  uni.navigateTo({
    url: "/subpackages/agree/pages/index",
  });
};

watch(
  () => agreedValue.value,
  (newValue) => {
    console.log(newValue, "agreed");
    emit("agreedValue", newValue);
  }
);
</script>
<style lang="scss" scoped>
.agree-box {
  display: flex;
  align-items: center;
}
.agree-text {
  margin-left: -46rpx;
  font-size: 14px;
  color: $primary-color;
}
</style>
