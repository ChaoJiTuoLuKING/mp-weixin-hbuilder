<template>
  <uni-data-checkbox
    v-bind="$attrs"
    v-model="checked"
    :localdata="localdata"
    selectedColor="var(--primary-color)"
    @change="onValueChanged"
  ></uni-data-checkbox>
</template>

<script setup>
import { ref, watch } from "vue";

// 定义 props
const props = defineProps({
  modelValue: {
    type: [Number, Array],
    default: 0,
  },
  localdata: {
    type: Array,
    default: () => [],
  },
});

// 定义 emit
const emit = defineEmits(["update:modelValue"]);

// 内部响应式数据
const checked = ref(props.modelValue);

// 监听 props 变化
watch(
  () => props.modelValue,
  (newValue) => {
    checked.value = newValue;
  }
);

// 处理值变化
const onValueChanged = (e) => {
  emit("update:modelValue", e.detail.value);
};
</script>

<style lang="scss" scoped>
:root {
  --primary-color: #009f52;
}
</style>
