<template>
  <uni-popup ref="popup" type="bottom" :safe-area="false" :is-mask-click="false">
    <view class="login-content">
      <view class="login-header-box">
        <text class="login-header-title">登录账号</text>
        <uni-icons
          type="closeempty"
          size="30"
          class="login-header-close"
          @click="handleClose"
        ></uni-icons>
      </view>

      <view class="login-content-wrap">
        <button
          class="login-btn"
          @click="handleLogin"
          :disabled="loading"
          :style="{ backgroundColor: loading ? '#b0e4c8' : '#07C160' }"
        >
          <view v-if="loading" class="loading-icon"></view>
          <text>{{ loading ? "登录中..." : "微信一键登录" }}</text>
        </button>
        <AgreeCheckBox @agreedValue="handleAgreedValue"></AgreeCheckBox>
      </view>
    </view>
  </uni-popup>
</template>

<script setup>
import { ref } from "vue";
import { useUserStore } from "@/stores/user.js";
import { getLoginApi } from "@/api/index";
import AgreeCheckBox from "@/components/agreeCheckBox.vue";

const loading = ref(false);
const popup = ref(null);
const agreedValue = ref(0);
const userStore = useUserStore();
const handleAgreedValue = (value) => {
  console.log("agreed  我说父组件", value);
  agreedValue.value = value;
};
const loginMessageError = (error = {}) => {
  uni.showToast({
    title: error.message || "登录失败",
    icon: "none",
  });
};
const handleClose = () => {
  console.log("close");
  uni.showTabBar({
    animation: true,
  });
  popup.value.close();
};
const goHomeRouter = () => {
  uni.switchTab({
    url: "/pages/home/index",
    success: () => {
      handleClose();
      console.log("成功跳转到订阅页面");
    },
    fail: (err) => {
      console.error("跳转失败", err);
      uni.showToast({
        title: "跳转失败",
        icon: "none",
      });
    },
  });
};
const getSession = async (res) => {
  let result = await getLoginApi({ js_code: res.code });
  if (result.errcode) {
    return;
  }
  userStore.setOpenid(result.openid);
  userStore.setSessionKey(result.session_key);
  return result;
};
const getWxLogin = async () => {
  uni.login({
    provider: "weixin",
    success: async (res) => {
      try {
        let result = await getSession(res);
        if (result && result.openid) {
          uni.showToast({
            title: "登录成功",
            icon: "none",
          });
          handleClose();
          //   goHomeRouter();//跳转订阅页面
        } else {
          loginMessageError();
        }
      } catch (error) {
        loginMessageError(error);
      }
    },
    fail: (err) => {
      loginMessageError(err);
    },
  });
};
const getWxUserInfo = async () => {
  let result = await uni.getUserInfo({
    provider: "weixin",
  });
  userStore.setUserInfo(result?.rawData ? JSON.parse(result.rawData) : {});
};
const handleLogin = async () => {
    console.log('login',agreedValue.value);
  if (agreedValue.value !== 1) {
    uni.showToast({
      title: "请先同意协议",
      icon: "none",
    });
    return;
  }
  loading.value = true;
  try {
    await getWxUserInfo();
    await getWxLogin();
    // console.log('loginll', userInfo);
  } catch (error) {
    loginMessageError(error);
  } finally {
    loading.value = false;
  }
};
// 暴露方法对外调用
defineExpose({
  open: (type) => {
    if (popup.value) {
      popup.value.open(type);
    }
  },
  close: () => {
    if (popup.value) {
      handleClose();
    }
  },
  popup: popup, // 直接暴露 popup 引用
});
</script>
<style lang="scss" scoped>
.login-content {
  // text-align: center;
  min-height: 200rpx;
  display: flex;
  flex-direction: column;
  background-color: $tip-border-color;
  border-radius: 20rpx 20rpx 0 0;
  .login-header-box {
    border-radius: 20rpx 20rpx 0 0;

    width: 100%;
    background-color: $white-text-color;
    color: $text-color;
    font-size: 36rpx;
    height: 100rpx;
    line-height: 100rpx;
    margin: auto;
    text-align: center;
    display: flex;
    flex-direction: row;
    position: relative;
    // justify-content: flex-end;
    // padding-right: 40rpx;
    .login-header-title {
      margin: auto;
    }
    .login-header-close {
      position: absolute;
      right: 20rpx;
    }
  }
  .login-content-wrap {
    height: 300rpx;
    display: flex;
    align-items: center;
    flex-direction: column;
    // justify-content: center;
    .login-btn {
      width: 80%;
      height: 90rpx;
      margin-top: 50rpx;
      border-radius: 45rpx;
      color: white;
      font-size: 32rpx;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 60rpx;
      box-shadow: 0 10rpx 20rpx $primary-color;
      border: none;
      outline: none;
    }
  }
}

.login-btn:active {
  opacity: 0.9;
  transform: translateY(4rpx);
}

.login-btn[disabled] {
  opacity: 0.7;
}
</style>
