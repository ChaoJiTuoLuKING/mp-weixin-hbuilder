import env from "./env.js";
import permission from "./permission.js";
console.log(env,'env')
// 基础配置
const BASE_URL = env.apiUrl;
const TIMEOUT = 15000; // 请求超时时间

// 请求拦截器
const requestInterceptor = (config) => {
  console.log(config, "config请求拦截");
  // 添加全局header (如token)
  const token =
    "eyJ0eXAiOiJKV1QiLCJhbGciOzI1NiJ9.eyJ3ZWNoYXRpZCI6Im90SkwwNXlVc1Nmb1VMdnJHMllJSnpqbjVUUmMiLCJ1c2VyU2FsdCI6IjQ4M3g2OTVRIiwiZXhwIjoxNzUzNjY1NzU2LCJ1c2VyaWQiOiJPUUFvNDBZempjZUt4cFgyN3AxM3Y2M0siLCJwbGF0Zm9ybSI6Im9mZmljaWFsIn0.7YEAU_lQjhgXQSLXjuCaEFIhHSSFvPYUJ6gJzIpD_xM";
  //   const token = permission.getToken()
  if (token) {
    config.header = {
      ...config.header,
      Authorization: token,
    };
  }
  // loading
  // if (config.showLoading) {
  //   uni.showLoading({ title: '加载中...', mask: true })
  // }

  return config;
};

// 响应拦截器
const responseInterceptor = (response, config) => {
  console.log(response, config, "config");
  // 隐藏loading
  // if (config.showLoading) uni.hideLoading()

  // 处理HTTP状态码
  if (response.statusCode === 401 || response?.data?.code === -10) {
    // 清除本地token
    permission.removeToken();
    uni.showToast({
        title: "请登录",
        icon: "none",
      });
    // 跳转到登录页
    permission.redirectToLogin();
    return response;
  }
  if (response.statusCode !== 200) {
    uni.showToast({
      title: `接口错误: ${response.statusCode}`,
      icon: "none",
    });
    return response;
  }

  const resData = response.data;
  if (resData.code !== 1) {
    // uni.showToast({ title: resData.message || "code错误", icon: "none" });
    // return Promise.reject(resData)
    return resData;
  }

  return resData.data; // 返回实际业务数据
};

// 错误处理
const errorHandler = (error, config) => {
  // loading
  // if (config.showLoading) uni.hideLoading()

  // 统一错误提示
  const errMsg = error.errMsg || "请求失败";
//   if (config.showError) {
    uni.showToast({ title: errMsg, icon: "none", duration: 3000 });
//   }
  if (error.statusCode === 401) {
    uni.showToast({
        title: "请登录",
        icon: "none",
      });
    permission.removeToken();
    permission.redirectToLogin();
  }
  // return Promise.reject(error)
  console.log(error, "error-------请求失败",config);
  return config;
};

// 核心请求方法
const request = (options) => {
  console.log(options, "options");
  // 合并配置
  const config = {
    url: "",
    method: "GET",
    data: {},
    header: {},
    timeout: TIMEOUT,
    // showLoading: true,
    // showError: true,
    ...options,
  };

    if (!config.ignoreBASEURL) {
        config.url = BASE_URL + config.url;
    }

  // 执行请求拦截
  requestInterceptor(config);

  // 请求
  return new Promise((resolve, reject) => {
    uni.request({
      ...config,
      success: (res) => {
        try {
          const data = responseInterceptor(res, config);
          resolve(data);
        } catch (e) {
          reject(e);
        }
      },
      fail: (err) => {
        errorHandler(err, config);
        reject(config);

        // reject(err);
      },
      complete: () => {},
    });
  });
};

export const get = (url, data = {}, options = {}) => {
  return request({ url, data, method: "GET", ...options });
};

export const post = (url, data = {}, options = {}) => {
  let config = {
    header: {
      "content-type": "application/json;charset=UTF-8",
    },
    ...options,
  };
  return request({ url, data, method: "POST", ...config });
};

export const put = (url, data = {}, options = {}) => {
  return request({ url, data, method: "PUT", ...options });
};

export const del = (url, data = {}, options = {}) => {
  return request({ url, data, method: "DELETE", ...options });
};

export default request;
