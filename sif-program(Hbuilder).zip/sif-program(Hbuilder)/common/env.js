const env = {
    development: {
      apiUrl: 'https://dev.sif.com',
    },
    production: {
      apiUrl: 'https://www.sif.com',
    }
  }
  
  const version = wx.getAccountInfoSync().miniProgram.envVersion
  let currentEnv = 'production'
  let miniprogram_state = 'formal'
  
  switch (version) {
    case 'develop':
      currentEnv = 'development'
      miniprogram_state = 'developer'
      break
      case 'trial':
        miniprogram_state = 'trial'
        break
    case 'release':
      currentEnv = 'production'
      miniprogram_state = 'formal'
      break
    default:
      currentEnv = 'development'
      miniprogram_state = 'formal'
  }
  
  export default {
    ...env[currentEnv],
    env: currentEnv,
    miniprogram_state
  }