// common/permission.js
export default {
  // 获取存储的token
  getToken() {
    return uni.getStorageSync("token") || "";
  },
  // 检查用户是否已登录
  checkLogin() {
    const token = this.getToken();
    return !!token;
  },

  // 保存token
  setToken(token) {
    uni.setStorageSync("token", token);
  },

  // 清除token
  removeToken() {
    uni.removeStorageSync("token");
  },
  
  // 跳转到登录页
  redirectToLogin() {
    uni.redirectTo({
      url: "/pages/login/index",
    });
  },

  // 导航到登录页
  navigateToLogin() {
    uni.navigateTo({
      url: "/pages/login/index",
    });
  },

  // 判断页面是否需要登录权限
  isNeedLogin(url) {
    // 不需要登录的页面
    const noNeedLoginPages = ["/pages/login/index"];

    return !noNeedLoginPages.includes(url);
  },
};
